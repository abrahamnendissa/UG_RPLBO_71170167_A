package com.rplbo.ug8;

public interface AttackingHero {
    public abstract void attack(Hero hero){

    }
}
