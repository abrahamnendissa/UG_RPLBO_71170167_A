package com.rplbo.ug8;

public class Golem extends SummonCharacter implements Summoner  {
    public Golem(Summoner Character){

    }
    private int kill;

    public void attack(Creep){

    }
    public Golem summon(){

        return null;
    }

    @Override
    public void Character() {

    }
}
