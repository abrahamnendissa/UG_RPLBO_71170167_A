package com.rplbo.ug8;

public class Warlock extends Hero implements Summoner {
    public Warlock(){

    }
    private int numOfSummon;

    public void attack(Creep){

    }
    public Golem summon(){

        return null;
    }

    @Override
    public void Character() {

    }
}
