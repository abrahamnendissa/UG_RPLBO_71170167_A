package com.rplbo.ug8;

public interface Summoner {
    public abstract void Character();
}
