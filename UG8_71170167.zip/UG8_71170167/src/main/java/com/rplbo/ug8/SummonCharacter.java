package com.rplbo.ug8;

import com.rplbo.ug8.Hero;
import com.rplbo.ug8.Summoner;

public class SummonCharacter extends Hero {
    public SummonCharacter(String , int Golem, int SpiritBear, Summoner Character){
        super();

    }

    public SummonCharacter() {

    }
    protected Summoner owner;

    @Override
    public void attack() {

    }
}
