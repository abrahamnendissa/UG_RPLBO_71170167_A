package com.rplbo.ug8;

public class SpiritBear extends SummonCharacter{
    public SpiritBear(LoneDruid summon){
        super();

    }
    public void attack (Creep creep){

    }
}
