package com.rplbo.ug8;

public interface Upgradeable {
    void upgrade();
}
