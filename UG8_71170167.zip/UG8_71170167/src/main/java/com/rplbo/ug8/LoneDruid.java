package com.rplbo.ug8;

public abstract class LoneDruid extends Hero implements Upgradeable, Summoner{
    public LoneDruid(int killCreep, int level){
        super();

    }

    SpiritBear summon (){

        return null;
    }

    public void upgrade(){

    }

    public void showCharacterInfo(){

    }

    public void attack(Creep creep){

    }
}
