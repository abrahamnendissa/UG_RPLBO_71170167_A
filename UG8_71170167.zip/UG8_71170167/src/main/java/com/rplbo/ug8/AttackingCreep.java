package com.rplbo.ug8;

public interface AttackingCreep {
    public abstract void attack(Creep);
}
