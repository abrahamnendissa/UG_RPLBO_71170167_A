package com.rplbo.ug8;

public abstract class Character {
    public Character(String name, int Hero, int Creep){

    }
    protected int damage;
    protected String name;
    protected int health;

    public Character() {

    }
}
