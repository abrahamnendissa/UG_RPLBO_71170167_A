package com.rplbo.ug8;

public class Creep extends Character implements AttackingHero{
    public Creep(String name, int damage,int health){

    }

    @Override
    public void attack(Hero hero) {

    }
}
