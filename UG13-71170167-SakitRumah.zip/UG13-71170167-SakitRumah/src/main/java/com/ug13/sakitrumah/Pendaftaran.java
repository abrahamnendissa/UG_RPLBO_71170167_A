package com.ug13.sakitrumah;

import java.util.Scanner;


public class Pendaftaran {
    private String nama;

    public Pendaftaran(String nama) {
        this.nama = nama;
    }

    public void mengaturJadwal (Pengunjung pengunjung, Pemeriksa pemeriksa, Jadwal jadwal){
        System.out.println("PENDAFTARAN BERHASIL");
    }

    public Pengunjung registrasi(){
        Scanner scanner = new Scanner(System.in);
        Scanner scanAngka = new Scanner(System.in);
        Jadwal jadwal = new Jadwal();

        System.out.print("Masukkan nama anda : ");
        String name = scanner.nextLine();
//        pengunjung.setNama(name);

        System.out.print("Masukkan usia anda : ");
        int age = scanAngka.nextInt();
//        pengunjung.setUsia(age);

        scanner.reset();
        System.out.print("Masukkan alamat anda : ");
        String address = scanner.nextLine();
//        pengunjung.setAlamat(address);

        System.out.print("Masukkan penyakit anda : ");
        String sick = scanner.nextLine();
//        pengunjung.setPenyakit(sick);

        Pengunjung saha = new Pengunjung(name, age, address);
        saha.setLevelPenyakit(3);
        jadwal.setPengunjung(saha);


        System.out.println("==========Proses Registrasi Berhasil==========");

        return saha;
    }
}
