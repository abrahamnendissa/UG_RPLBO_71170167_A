package com.ug13.sakitrumah;

public class Jadwal {
    private Pengunjung pengunjung;
    private Pemeriksa pemeriksa;
    private Perawat perawat;
    private Pendaftaran pendaftaran;
    private boolean statusDaftar = false;
    private boolean statusScreening = false;

    public Pengunjung getPengunjung() {
        return pengunjung;
    }

    public Pemeriksa getPemeriksa() {
        return pemeriksa;
    }

    public Perawat getPerawat() {
        return perawat;
    }

    public Pendaftaran getPendaftaran() {
        return pendaftaran;
    }

    public boolean isStatusDaftar() {
        return statusDaftar;
    }

    public boolean isStatusScreening() {
        return statusScreening;
    }

    public void setPengunjung(Pengunjung pengunjung) {
        this.pengunjung = pengunjung;
    }

    public void setPemeriksa(Pemeriksa pemeriksa) {
        this.pemeriksa = pemeriksa;
    }

    public void setPerawat(Perawat perawat) {
        this.perawat = perawat;
    }

    public void setPendaftaran(Pendaftaran pendaftaran) {
        this.pendaftaran = pendaftaran;
    }

    public void setStatusDaftar(boolean statusDaftar) {
        this.statusDaftar = statusDaftar;
    }

    public void setStatusScreening(boolean statusScreening) {
        this.statusScreening = statusScreening;
    }

}