package com.ug13.sakitrumah;

public class App {
    public static void main(String[] args) {
        System.out.println("===========================================PROSES INISIALISASI============================================");
        System.out.println();
        Jadwal jadwal = new Jadwal();
        Pengunjung baru = new Pengunjung("Fernando",12,"maguwo");
        Pendaftaran pendaftaran = new Pendaftaran("Toto");
        Perawat perawat = new Perawat("Ica");
        Pemeriksa pemeriksa = new Pemeriksa("Eko", "Jantung", "D36");
        Pengunjung pengunjung = pendaftaran.registrasi();
        pendaftaran.mengaturJadwal(pengunjung, pemeriksa, jadwal);
        System.out.println();
        perawat.screening(baru, jadwal);
        pemeriksa.memeriksa(baru, jadwal);
        perawat.screening(pengunjung, jadwal);
        System.out.println("SEDANG PROSES PEMERIKSAAN");
        System.out.println();
        int x = pengunjung.getLevelPenyakit();
        for(int i = 0; i <= x; i++) {
            pemeriksa.memeriksa(pengunjung, jadwal);
            pemeriksa.cekStatus(pengunjung);
        }

        System.out.println(jadwal.getPengunjung().getStatus());
        System.out.println(jadwal.getPengunjung().getLevelPenyakit());
    }
}