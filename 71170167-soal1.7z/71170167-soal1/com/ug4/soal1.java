public class soal1 {
    public static void (String[args]){

    }
}
