package com.ug14.rumahsakit;

public class DAO {
    public void Dokter{
        getDokterById(int idDokter){
            
        }
    }

    public static void getPasienSembuh() {
    }

    protected void inputPasien(Pasien pasien) {
    }
}
