package com.ug14.rumahsakit;

public class Pasien {
    private String nama, alamat, penyakit;
    private int rm, usia, levelPenyakit;
    private boolean status = false;

    public Pasien(int rm, String nama, int usia, String alamat ) {
        this.rm;
        this.nama = nama;
        this.alamat = alamat;
        this.usia = usia;
    }



    public String getNama() {
        return nama;
    }

    public String getAlamat() {
        return alamat;
    }

    public String getPenyakit() {
        return penyakit;
    }

    public boolean getStatus() {
        return status;
    }

    public int getUsia() {
        return usia;
    }

    public int getLevelPenyakit() {
        return levelPenyakit;
    }

    public void setLevelPenyakit(int levelPenyakit) {
        this.levelPenyakit = levelPenyakit;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public void setAlamat(String alamat) {
        this.alamat = alamat;
    }

    public void setPenyakit(String penyakit) {
        this.penyakit = penyakit;
    }

    public void setUsia(int usia) {
        this.usia = usia;
    }

    public int getRm() {
        return rm;
    }

    public void setRm(int rm) {
        this.rm = rm;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
}
