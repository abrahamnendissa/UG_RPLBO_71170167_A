package com.ug14.rumahsakit;

public class Dokter {
    private String nama, spesialis, ruangan;
    private int idDokter;

    public Dokter(String nama, String spesialis, String ruangan) {
        this.nama = nama;
        this.spesialis = spesialis;
        this.ruangan = ruangan;
    }

    public void memeriksa(Pasien pasien, Jadwal jadwal){
        if (jadwal.isStatusScreening()){
//            System.out.println("==========PROSES PEMERIKSAAN DOKTER==========");
            pasien.setLevelPenyakit((pasien.getLevelPenyakit() - 1));
        }
    }

    public void cekStatus(Pasien pasien, Jadwal jadwal){
        if (pasien.getLevelPenyakit() < 0){
            System.out.println("==========PASIEN TELAH SEMBUH==========");
        } else {
            System.out.println("==========PASIEN ANDA MASIH SAKIT==========");
        }
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getSpesialis() {
        return spesialis;
    }

    public void setSpesialis(String spesialis) {
        this.spesialis = spesialis;
    }

    public String getRuangan() {
        return ruangan;
    }

    public void setRuangan(String ruangan) {
        this.ruangan = ruangan;
    }

    public int getIdDokter() {
        return idDokter;
    }

    public void setIdDokter(int idDokter) {
        this.idDokter = idDokter;
    }
}
